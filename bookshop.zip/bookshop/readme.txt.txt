log in address: localhost/bookshop/view/login.php


admin----> username: sahil34 & password: 1234
buyer----> username: asraf33 & password: 1234
seller---> username: hamim89 & password: 1234
Delivery man--> username: tanvir33 & password: 1234