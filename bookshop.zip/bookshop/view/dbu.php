<?php
    $conn = new mysqli("localhost", "root", "","bookshop");
    
    

?>