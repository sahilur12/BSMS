<?php
session_start(); 
include('../control/db.php');
//include('../control/updateadmincheck.php');

if(empty($_SESSION["username"])) // Destroying All Sessions
{
  header("Location: ../control/login.php"); // Redirecting To Home Page
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="../css/dcss.css">
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
  <script>
    $(document).ready(function(){
      

    function validateForm() {
  var isValid;
  var x = document.forms["myForm"]["firstname"].value;
  var x1 = document.forms["myForm"]["email"].value;
  var x2 = document.forms["myForm"]["address"].value;
  var x3 = document.forms["myForm"]["phoneno"].value;
  var x4 = document.forms["myForm"]["nid"].value;
  var x5 = document.forms["myForm"]["dob"].value;
  if (x == "" ) {
    
    document.getElementById("errorMsg").innerHTML = "<b>firstname must be filled out.</b>";
    document.getElementById("errorMsg").style.color = "red";
    isValid = false
  }
  else{
    document.getElementById("errorMsg").innerHTML = "";
  }
   if(x1 == "") {

    document.getElementById("errorMsg1").innerHTML = "<b>email must be filled out.</b>";
    document.getElementById("errorMsg1").style.color = "red";
    isValid = false
  }
  else{
    document.getElementById("errorMsg1").innerHTML = "";
  }
  if (x2 == "" ) {
    document.getElementById("errorMsg2").innerHTML = "<b>address must be filled out.</b>";
    document.getElementById("errorMsg2").style.color = "red";
    isValid = false
  }
  else{
    document.getElementById("errorMsg2").innerHTML = "";
  }
  if (x3 == "" ) {
    document.getElementById("errorMsg3").innerHTML = "<b>phoneno must be filled out.</b>";
    document.getElementById("errorMsg3").style.color = "red";
    isValid = false
  }
  else{
    document.getElementById("errorMsg3").innerHTML = "";
  }
  if (x4 == "" ) {
    document.getElementById("errorMsg4").innerHTML = "<b>nid must be filled out.</b>";
    document.getElementById("errorMsg4").style.color = "red";
    isValid = false
  }
  else{
    document.getElementById("errorMsg4").innerHTML = "";
  }
  if (x5 == "" ) {
    document.getElementById("errorMsg5").innerHTML = "<b>dob must be filled out.</b>";
    document.getElementById("errorMsg5").style.color = "red";
    isValid = false
  }
  
else {
          isValid = true;
        }
return isValid;
}

$('#submitFrom').click(function() 
{

    if(validateForm()){
        var x = document.forms["myForm"]["firstname"].value;
      var x1 = document.forms["myForm"]["email"].value;
      var x2 = document.forms["myForm"]["address"].value;
      var x3 = document.forms["myForm"]["phoneno"].value;
      var x4 = document.forms["myForm"]["nid"].value;
      var x5 = document.forms["myForm"]["dob"].value;

var postData = 'firstname=' + x + '&email=' + x1 + '&address=' + x2 + '&phoneno=' + x3 + '&nid=' + x4 + '&dob=' + x5;


    $.ajax({
          url: "../control/admin_update.php",
          type: "POST",
          
          data: postData,
          success: function(data, status, xhr) {
          //if success then just output the text to the status div then clear the form inputs to prepare for new data
            $("#ajaxResult").html(data);
            // $('#name').val('');
            // $('#percentage').val('');
          },
          error: function(jqXHR, status, errorThrown) {
         
          //if fail show error and server status
            //$("#ajaxResult").html('there was an error ' + errorThrown + ' with status ' + textStatus);
          }
        })
  }
      
});





});

</script>




<head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Lato:wght@300&display=swap');
h1 {text-align: center;}
h2 {text-align: center;}
h3 {text-align: center;}

p {text-align: center;}
body {
  font-family: 'Lato', sans-serif;
  background-image: url('background/image3.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: 100% 100%;
}
a:link, a:visited {
  background-color:  rgb(99, 43, 4);
  color:  white;
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: green;
}
</style>
</head>    
<body>
<body>
<div>
<h1>Update Profile Information</h1>
</div>
<div>
<tr><th><a href="adminhome.php">Admin Home Page</a></th>
<tr><th><a href="../control/logout.php">logout</a></th></div>
<h3>Hii, <?php echo $_SESSION["username"];?></h3>


</head>

<?php
if(isset($_COOKIE["updatedAt"]))
{
  echo "Last Updated at ".$_COOKIE["updatedAt"];
}
$connection = new db();
$conobj=$connection->OpenCon();

$userQuery=$connection->CheckUser($conobj,"users",$_SESSION["username"],$_SESSION["password"],$_SESSION["type"]);

if ($userQuery->num_rows > 0) {
  echo "<form action='' method='post'>";
      while($row = $userQuery->fetch_assoc()) {
        
        echo "<tr><tr><tr><th>firstname : <input type='text' name='firstname' value=".$row["firstname"]." ><p id='errorMsg'></p><br><hr>";
        echo "Email : <input type='text' name='email' value=".$row["email"]." ><p id='errorMsg1'></p> <br><hr>";
        echo "Address : <input type='text' name='address' value=".$row["address"]." ><p id='errorMsg2'></p> <br><hr>";
        echo "Phone NO : <input type='text' name='phoneno' value=".$row["phoneno"]." ><p id='errorMsg3'></p> <br><hr>";
        echo "National ID NO: <input type='text' name='nid' value=".$row["nid"]." ><p id='errorMsg4'></p> <br><hr>";
        echo "Date Of Birth : <input type='text' name='dob' value=".$row["dob"]." ><p id='errorMsg5'></p> <br><hr>";
      
    }
    echo   "<input name='update' type='submit' value='Update'>";
    echo "</table>";
  } else {
    echo "0 results";
  }

?>

</body>
</html>

